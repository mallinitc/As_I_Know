"use client";

import { useState } from "react";

import {
  MapContainer,
  TileLayer,
  GeoJSON,
  CircleMarker,
  useMapEvents,
} from "react-leaflet";

import "leaflet/dist/leaflet.css";

import type { Feature, Geometry } from "geojson";

// ============================================================
// 1. TYPES
// ============================================================

type SourceInvestigation = {
  source: string;
  status: string;
  access_method?: string;
  attributes_found?: Record<string, unknown>;
  attributes_missing?: string[];
  source_timestamp?: string | null;
  dataset_year?: number;
  verification?: string;
  investigated_at?: string | null;
};

type SourceInvestigationReport = {
  building_id: string;
  report_generated_at: string;
  sources_checked: number;
  sources_pending: number;
  investigations: SourceInvestigation[];
};

type NearbyCandidate = {
  building_id: string;
  distance_m: number;
  building_type?: string | null;
  estimated_height_m?: number | null;
  source?: string;
  geometry?: Geometry;
};

type BuildingResult = {
  match_type: "exact" | "none" | "error";

  building_id?: string;
  latitude?: number;
  longitude?: number;
  message?: string;

  building_type?: string | null;
  building_levels?: string | null;
  height?: string | null;
  construction_date?: string | null;

  source?: string;
  source_timestamp?: string | null;

  estimated_height_m?: number | null;
  height_estimate_source?: string | null;
  height_estimate_year?: number | null;
  height_verification?: string | null;
  height_sampling_method?: string | null;

  geometry?: Geometry;

  source_investigation?: SourceInvestigationReport;

  nearby_candidates?: NearbyCandidate[];
  nearby_count?: number;
  search_radius_m?: number;
  distance_method?: string;
};

// ============================================================
// 2. MAP CLICK HANDLER
// ============================================================

function MapClickHandler({
  onBuildingSelected,
  onLoading,
}: {
  onBuildingSelected: (result: BuildingResult) => void;
  onLoading: (loading: boolean) => void;
}) {
  useMapEvents({
    async click(event) {
      const { lat, lng } = event.latlng;

      onLoading(true);

      try {
        const response = await fetch(
          `http://127.0.0.1:8000/building/query?lat=${lat}&lon=${lng}`
        );

        if (!response.ok) {
          throw new Error(`API error: ${response.status}`);
        }

        const result: BuildingResult = await response.json();

        onBuildingSelected(result);
      } catch (error) {
        console.error("Building query failed:", error);

        onBuildingSelected({
          match_type: "error",
          latitude: lat,
          longitude: lng,
          message: "Unable to connect to Building Intelligence API.",
        });
      } finally {
        onLoading(false);
      }
    },
  });

  return null;
}

// ============================================================
// 3. REUSABLE ATTRIBUTE ROW
// ============================================================

function AttributeRow({
  label,
  value,
}: {
  label: string;
  value: string | number | null | undefined;
}) {
  return (
    <div
      style={{
        marginBottom: "8px",
        fontSize: "13px",
        overflowWrap: "anywhere",
      }}
    >
      <strong>{label}:</strong>{" "}
      {value !== null && value !== undefined && value !== ""
        ? String(value)
        : "Unknown"}
    </div>
  );
}

// ============================================================
// 4. SOURCE INVESTIGATION PANEL
// ============================================================

function SourceInvestigationPanel({
  report,
}: {
  report: SourceInvestigationReport;
}) {
  return (
    <div
      style={{
        marginTop: "18px",
        padding: "12px",
        background: "#ffffff",
        border: "1px solid #cbd5e1",
        borderRadius: "8px",
      }}
    >
      <h3
        style={{
          marginBottom: "12px",
          fontSize: "15px",
          fontWeight: 700,
          color: "#102a43",
        }}
      >
        Source Investigation
      </h3>

      <div
        style={{
          display: "flex",
          gap: "10px",
          marginBottom: "12px",
        }}
      >
        <div
          style={{
            flex: 1,
            padding: "10px",
            background: "#dcfce7",
            borderRadius: "6px",
            textAlign: "center",
          }}
        >
          <strong
            style={{
              fontSize: "20px",
              color: "#166534",
            }}
          >
            {report.sources_checked}
          </strong>

          <div style={{ fontSize: "11px" }}>
            Sources Checked
          </div>
        </div>

        <div
          style={{
            flex: 1,
            padding: "10px",
            background: "#f1f5f9",
            borderRadius: "6px",
            textAlign: "center",
          }}
        >
          <strong
            style={{
              fontSize: "20px",
              color: "#475569",
            }}
          >
            {report.sources_pending}
          </strong>

          <div style={{ fontSize: "11px" }}>
            Not Yet Searched
          </div>
        </div>
      </div>

      {report.investigations.map((item, index) => {
        const completed = item.status === "completed";
        const notSearched = item.status === "not_searched";

        return (
          <div
            key={`${item.source}-${index}`}
            style={{
              marginBottom: "10px",
              padding: "10px",
              border: "1px solid #e2e8f0",
              borderRadius: "6px",
              background: completed ? "#f0fdf4" : "#f8fafc",
            }}
          >
            <div
              style={{
                fontWeight: 700,
                fontSize: "13px",
              }}
            >
              {item.source}
            </div>

            <div
              style={{
                fontSize: "12px",
                fontWeight: 600,
                margin: "6px 0",
                color: completed
                  ? "#15803d"
                  : notSearched
                    ? "#64748b"
                    : "#b45309",
              }}
            >
              {completed
                ? "✓ Data checked"
                : notSearched
                  ? "○ Not yet searched"
                  : item.status.replaceAll("_", " ")}
            </div>

            {item.access_method && (
              <AttributeRow
                label="Access"
                value={item.access_method}
              />
            )}

            {item.attributes_found &&
              Object.keys(item.attributes_found).length > 0 && (
                <div style={{ marginBottom: "8px" }}>
                  <strong
                    style={{
                      fontSize: "12px",
                      color: "#166534",
                    }}
                  >
                    Information Found
                  </strong>

                  {Object.entries(item.attributes_found).map(
                    ([key, value]) => (
                      <div
                        key={key}
                        style={{
                          fontSize: "12px",
                          marginTop: "4px",
                          overflowWrap: "anywhere",
                        }}
                      >
                        {key}: {String(value)}
                      </div>
                    )
                  )}
                </div>
              )}

            {item.attributes_missing &&
              item.attributes_missing.length > 0 && (
                <div
                  style={{
                    fontSize: "12px",
                    color: "#b45309",
                    marginBottom: "8px",
                  }}
                >
                  <strong>Missing:</strong>{" "}
                  {item.attributes_missing.join(", ")}
                </div>
              )}

            {item.dataset_year && (
              <AttributeRow
                label="Dataset Year"
                value={item.dataset_year}
              />
            )}

            {item.verification && (
              <AttributeRow
                label="Verification"
                value={item.verification}
              />
            )}

            {item.source_timestamp && (
              <AttributeRow
                label="Source Updated"
                value={item.source_timestamp}
              />
            )}
          </div>
        );
      })}

      <p
        style={{
          fontSize: "11px",
          color: "#64748b",
          marginTop: "12px",
          lineHeight: 1.5,
        }}
      >
        These results use locally imported datasets.
        Unsearched sources have not been queried automatically.
        Report generated:{" "}
        {new Date(report.report_generated_at).toLocaleString()}.
      </p>
    </div>
  );
}

// ============================================================
// 5. NEARBY BUILDING CANDIDATES PANEL
// ============================================================

function NearbyBuildingsPanel({
  candidates,
  radius,
}: {
  candidates: NearbyCandidate[];
  radius: number;
}) {
  return (
    <div
      style={{
        padding: "12px",
        marginTop: "14px",
        background: "#fff7ed",
        border: "1px solid #fdba74",
        borderRadius: "8px",
      }}
    >
      <h3
        style={{
          fontSize: "15px",
          fontWeight: 700,
          color: "#9a3412",
          marginBottom: "10px",
        }}
      >
        Nearby Building Candidates
      </h3>

      <p
        style={{
          fontSize: "12px",
          marginBottom: "12px",
          lineHeight: 1.5,
        }}
      >
        No building polygon contains the clicked location.
        The following mapped buildings are nearby, but none
        is confirmed to be the selected building.
      </p>

      <AttributeRow
        label="Search Radius"
        value={`${radius} metres`}
      />

      <AttributeRow
        label="Candidates Found"
        value={candidates.length}
      />

      {candidates.length === 0 && (
        <p style={{ fontSize: "13px", marginTop: "12px" }}>
          No mapped building candidates were found within
          the search radius.
        </p>
      )}

      {candidates.map((candidate, index) => (
        <div
          key={candidate.building_id}
          style={{
            padding: "12px",
            marginTop: "10px",
            background: "#ffffff",
            border: "1px solid #fed7aa",
            borderRadius: "6px",
          }}
        >
          <div
            style={{
              fontWeight: 700,
              fontSize: "13px",
              marginBottom: "8px",
              color: "#9a3412",
            }}
          >
            Candidate {index + 1}
          </div>

          <AttributeRow
            label="Building ID"
            value={candidate.building_id}
          />

          <AttributeRow
            label="Distance"
            value={`${candidate.distance_m.toFixed(2)} metres`}
          />

          <AttributeRow
            label="Building Tag"
            value={candidate.building_type}
          />

          <AttributeRow
            label="Estimated Height"
            value={
              candidate.estimated_height_m != null
                ? `${candidate.estimated_height_m.toFixed(2)} m`
                : "Unknown"
            }
          />

          <AttributeRow
            label="Source"
            value={candidate.source}
          />

          <p
            style={{
              fontSize: "11px",
              color: "#92400e",
            }}
          >
            Proximity match only — not an exact building identification.
            Height, if shown, is a Google 2023 model estimate.
          </p>
        </div>
      ))}
    </div>
  );
}

// ============================================================
// 6. BUILDING INTELLIGENCE PANEL
// ============================================================

function BuildingIntelligencePanel({
  selectedBuilding,
  loading,
}: {
  selectedBuilding: BuildingResult | null;
  loading: boolean;
}) {
  return (
    <aside
      style={{
        width: "30%",
        minWidth: "300px",
        height: "100%",
        overflowY: "auto",
        background: "#f8fafc",
        padding: "18px",
        color: "#172033",
        boxSizing: "border-box",
        borderLeft: "1px solid #cbd5e1",
      }}
    >
      <h2
        style={{
          fontSize: "18px",
          fontWeight: 700,
          marginBottom: "14px",
          color: "#102a43",
        }}
      >
        Building Intelligence
      </h2>

      {loading && (
        <p style={{ color: "#2563eb" }}>
          Identifying building...
        </p>
      )}

      {!selectedBuilding && !loading && (
        <p style={{ fontSize: "13px", lineHeight: 1.6 }}>
          Click a location on the Moosarambagh map to
          investigate building footprints and attributes.
        </p>
      )}

      {selectedBuilding?.match_type === "error" && (
        <div
          style={{
            padding: "12px",
            background: "#fef2f2",
            borderRadius: "6px",
            color: "#b91c1c",
          }}
        >
          {selectedBuilding.message}
        </div>
      )}

      {/* NO EXACT MATCH */}

      {selectedBuilding?.match_type === "none" && (
        <>
          <div
            style={{
              padding: "12px",
              background: "#ffedd5",
              borderRadius: "6px",
              color: "#9a3412",
              fontSize: "13px",
            }}
          >
            <strong>No Exact Building Match</strong>

            <p style={{ marginTop: "8px" }}>
              {selectedBuilding.message}
            </p>
          </div>

          <NearbyBuildingsPanel
            candidates={selectedBuilding.nearby_candidates ?? []}
            radius={selectedBuilding.search_radius_m ?? 100}
          />
        </>
      )}

      {/* EXACT MATCH */}

      {selectedBuilding?.match_type === "exact" && (
        <>
          <div
            style={{
              padding: "12px",
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "8px",
            }}
          >
            <div
              style={{
                color: "#15803d",
                fontWeight: 700,
                marginBottom: "12px",
                fontSize: "13px",
              }}
            >
              ✓ Exact Polygon Match
            </div>

            <AttributeRow
              label="Building ID"
              value={selectedBuilding.building_id}
            />

            <AttributeRow
              label="Building Tag"
              value={selectedBuilding.building_type}
            />

            <AttributeRow
              label="Floors"
              value={selectedBuilding.building_levels}
            />

            <AttributeRow
              label="OSM Height"
              value={selectedBuilding.height}
            />

            <AttributeRow
              label="Construction Year"
              value={selectedBuilding.construction_date}
            />

            <AttributeRow
              label="Source"
              value={selectedBuilding.source}
            />

            <AttributeRow
              label="Source Updated"
              value={selectedBuilding.source_timestamp}
            />

            {selectedBuilding.building_type === "yes" && (
              <p
                style={{
                  fontSize: "11px",
                  color: "#64748b",
                  marginTop: "10px",
                }}
              >
                The OSM tag "yes" identifies this feature as a
                building. It does not confirm residential or
                commercial occupancy.
              </p>
            )}
          </div>

          {/* GOOGLE HEIGHT */}

          <div
            style={{
              marginTop: "14px",
              padding: "12px",
              background: "#e8f4ff",
              border: "1px solid #90caf9",
              borderRadius: "8px",
            }}
          >
            <h3
              style={{
                fontSize: "15px",
                fontWeight: 700,
                marginBottom: "12px",
                color: "#102a43",
              }}
            >
              Google Building Height Intelligence
            </h3>

            {selectedBuilding.estimated_height_m != null ? (
              <>
                <div
                  style={{
                    fontSize: "26px",
                    fontWeight: 700,
                    color: "#1d4ed8",
                    marginBottom: "10px",
                  }}
                >
                  {selectedBuilding.estimated_height_m.toFixed(2)} m
                </div>

                <AttributeRow
                  label="Source"
                  value={selectedBuilding.height_estimate_source}
                />

                <AttributeRow
                  label="Dataset Year"
                  value={selectedBuilding.height_estimate_year}
                />

                <AttributeRow
                  label="Verification"
                  value={selectedBuilding.height_verification}
                />

                <AttributeRow
                  label="Sampling Method"
                  value={selectedBuilding.height_sampling_method}
                />

                <p
                  style={{
                    fontSize: "11px",
                    color: "#475569",
                    lineHeight: 1.5,
                    marginTop: "10px",
                  }}
                >
                  Satellite-derived model estimate sampled
                  at one representative point. Not a
                  field-verified measurement.
                </p>
              </>
            ) : (
              <p style={{ fontSize: "13px" }}>
                No Google height estimate available.
              </p>
            )}
          </div>

          {/* SOURCE INVESTIGATION */}

          {selectedBuilding.source_investigation && (
            <SourceInvestigationPanel
              report={selectedBuilding.source_investigation}
            />
          )}
        </>
      )}
    </aside>
  );
}

// ============================================================
// 7. MAIN INTERACTIVE MAP
// ============================================================

export default function BuildingMap() {
  const [selectedBuilding, setSelectedBuilding] =
    useState<BuildingResult | null>(null);

  const [loading, setLoading] = useState(false);

  // Exact building polygon
  const buildingFeature: Feature<Geometry> | null =
    selectedBuilding?.match_type === "exact" &&
    selectedBuilding.geometry
      ? {
          type: "Feature",
          properties: {},
          geometry: selectedBuilding.geometry,
        }
      : null;

  // Nearby candidate polygons
  const candidateFeatures: Feature<Geometry>[] =
    selectedBuilding?.match_type === "none"
      ? (selectedBuilding.nearby_candidates ?? [])
          .filter(
            (candidate) => candidate.geometry !== undefined
          )
          .map((candidate) => ({
            type: "Feature",
            properties: {
              building_id: candidate.building_id,
              distance_m: candidate.distance_m,
            },
            geometry: candidate.geometry!,
          }))
      : [];

  return (
    <div
      style={{
        display: "flex",
        height: "85vh",
        width: "100%",
      }}
    >
      {/* MAP */}

      <div
        style={{
          width: "70%",
          height: "100%",
        }}
      >
        <MapContainer
          center={[17.371, 78.512]}
          zoom={18}
          maxZoom={21}
          style={{
            width: "100%",
            height: "100%",
          }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
            maxNativeZoom={19}
            maxZoom={21}
          />

          <MapClickHandler
            onBuildingSelected={setSelectedBuilding}
            onLoading={setLoading}
          />

          {/* EXACT MATCH — RED */}

          {buildingFeature && (
            <GeoJSON
              key={`exact-${selectedBuilding?.building_id}`}
              data={buildingFeature}
              style={{
                color: "#ef4444",
                weight: 3,
                fillColor: "#ef4444",
                fillOpacity: 0.45,
              }}
            />
          )}

          {/* NEARBY CANDIDATES — ORANGE */}

          {candidateFeatures.map((feature, index) => (
            <GeoJSON
              key={`candidate-${index}-${feature.properties?.building_id}`}
              data={feature}
              style={{
                color: "#f97316",
                weight: 3,
                fillColor: "#fb923c",
                fillOpacity: 0.35,
              }}
            />
          ))}

          {/* CLICKED LOCATION — BLUE MARKER */}

          {selectedBuilding?.match_type === "none" &&
            selectedBuilding.latitude !== undefined &&
            selectedBuilding.longitude !== undefined && (
              <CircleMarker
                center={[
                  selectedBuilding.latitude,
                  selectedBuilding.longitude,
                ]}
                radius={6}
                pathOptions={{
                  color: "#1d4ed8",
                  fillColor: "#2563eb",
                  fillOpacity: 1,
                  weight: 2,
                }}
              />
            )}
        </MapContainer>
      </div>

      {/* SIDEBAR */}

      <BuildingIntelligencePanel
        selectedBuilding={selectedBuilding}
        loading={loading}
      />
    </div>
  );
}