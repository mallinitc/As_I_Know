"""
AI NETRA — Hyderabad Building Intelligence API
Version: 0.3.0
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.encoders import jsonable_encoder

from scripts.query_building import identify_building, buildings
from scripts.source_investigation import investigate_building


app = FastAPI(
    title="AI NETRA — Building Intelligence API",
    description="Evidence-backed building intelligence for flood rescue.",
    version="0.3.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000"
    ],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "project": "AI NETRA",
        "workstream": "Building Intelligence",
        "buildings_loaded": len(buildings),
        "version": "0.3.0"
    }


@app.get("/building/query")
def query_building(
    lat: float = Query(..., ge=-90, le=90),
    lon: float = Query(..., ge=-180, le=180)
):
    try:
        result = identify_building(lat, lon)

        if result["match_type"] == "exact":
            result["source_investigation"] = (
                investigate_building(result)
            )

        return jsonable_encoder(result)

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail="Building identification failed."
        ) from exc