"""
AI NETRA — Hyderabad Building Intelligence
Workstream: GEO-001
Version: 0.3.0

Capabilities:
1. Load real OpenStreetMap building polygons.
2. Identify buildings using point-in-polygon matching.
3. Retrieve Google Open Buildings 2.5D height estimates.
4. Preserve source provenance and verification status.
5. Find nearby building candidates when no exact match exists.

Dependencies:
- Python 3.11
- Shapely

No GeoPandas, Pandas, or PyProj required.
"""

import csv
import json
import math

from pathlib import Path

from shapely.geometry import Point, shape, mapping
from shapely.ops import transform


# ============================================================
# 1. PROJECT CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

OSM_FILE = (
    PROJECT_ROOT
    / "data"
    / "moosarambagh_osm_buildings.geojson"
)

HEIGHT_FILE = (
    PROJECT_ROOT
    / "data"
    / "ai_netra_building_heights_2023_v1.csv"
)

NEARBY_SEARCH_RADIUS_M = 100

MAX_NEARBY_CANDIDATES = 5


# ============================================================
# 2. LOAD OPENSTREETMAP BUILDINGS
# ============================================================

with open(OSM_FILE, "r", encoding="utf-8") as file:
    osm_data = json.load(file)

buildings = []

for feature in osm_data.get("features", []):

    properties = feature.get("properties", {})

    geometry = shape(feature["geometry"])

    if geometry.is_empty or not geometry.is_valid:

        print(
            "Warning: Skipping invalid geometry:",
            properties.get("building_id")
        )

        continue

    buildings.append({
        "properties": properties,
        "geometry": geometry
    })

print(f"Loaded {len(buildings)} OSM building polygons")


# ============================================================
# 3. LOAD GOOGLE BUILDING HEIGHT ESTIMATES
# ============================================================

height_lookup = {}

if HEIGHT_FILE.exists():

    with open(
        HEIGHT_FILE,
        newline="",
        encoding="utf-8-sig"
    ) as file:

        reader = csv.DictReader(file)

        for row in reader:

            building_id = row.get("building_id")

            raw_height = row.get("estimated_height_m")

            if not building_id or not raw_height:
                continue

            try:

                height = float(raw_height)

                if not math.isfinite(height) or height <= 0:
                    continue

                height_lookup[building_id] = height

            except (ValueError, TypeError):
                continue

    print(
        f"Loaded {len(height_lookup)} "
        "Google building-height estimates"
    )

else:

    print(
        "Warning: Google building-height CSV not found. "
        "OSM-only building identification remains available."
    )


# ============================================================
# 4. GEOGRAPHIC DISTANCE FUNCTIONS
# ============================================================

def project_to_local_metres(
    geometry,
    reference_latitude,
    reference_longitude
):
    """
    Convert WGS84 longitude/latitude coordinates into
    approximate local metre coordinates.

    Uses a local equirectangular projection.

    This approximation is suitable for the small
    100-metre search radius in the Moosarambagh pilot.

    It must not be used for large-area measurements
    or authoritative surveying.
    """

    earth_radius_m = 6371008.8

    reference_lat_rad = math.radians(reference_latitude)

    reference_lon_rad = math.radians(reference_longitude)

    def converter(lon, lat, z=None):

        lon_rad = math.radians(lon)

        lat_rad = math.radians(lat)

        x = (
            earth_radius_m
            * (lon_rad - reference_lon_rad)
            * math.cos(reference_lat_rad)
        )

        y = (
            earth_radius_m
            * (lat_rad - reference_lat_rad)
        )

        if z is not None:
            return x, y, z

        return x, y

    return transform(converter, geometry)


# ============================================================
# 5. FIND NEARBY BUILDINGS
# ============================================================

def find_nearby_buildings(
    latitude,
    longitude,
    radius_m=NEARBY_SEARCH_RADIUS_M,
    limit=MAX_NEARBY_CANDIDATES
):
    """
    Find nearby OSM building polygons.

    Distance is measured from the clicked coordinate
    to the nearest point on each building polygon.

    Returned buildings are candidates, not exact matches.
    """

    clicked_point = Point(longitude, latitude)

    projected_point = project_to_local_metres(
        clicked_point,
        latitude,
        longitude
    )

    candidates = []

    for building in buildings:

        geometry = building["geometry"]

        properties = building["properties"]

        projected_geometry = project_to_local_metres(
            geometry,
            latitude,
            longitude
        )

        distance_m = projected_point.distance(
            projected_geometry
        )

        if distance_m <= radius_m:

            building_id = properties.get("building_id")

            candidates.append({

                "building_id": building_id,

                "distance_m": round(distance_m, 2),

                "building_type": properties.get(
                    "building_type"
                ),

                "estimated_height_m": height_lookup.get(
                    building_id
                ),

                "source": properties.get(
                    "source",
                    "OpenStreetMap"
                ),

                "geometry": mapping(geometry)

            })

    candidates.sort(
        key=lambda item: (
            item["distance_m"],
            item["building_id"] or ""
        )
    )

    return candidates[:limit]


# ============================================================
# 6. BUILDING IDENTIFICATION
# ============================================================

def identify_building(latitude, longitude):
    """
    Identify the building containing a selected coordinate.

    If no polygon contains the coordinate, return
    nearby building candidates within 100 metres.

    Exact match = geometric point-in-polygon match.

    Nearby match = proximity only, not identification.
    """

    if not (
        math.isfinite(latitude)
        and math.isfinite(longitude)
        and -90 <= latitude <= 90
        and -180 <= longitude <= 180
    ):

        raise ValueError(
            "Invalid latitude or longitude"
        )

    clicked_point = Point(longitude, latitude)

    matches = [
        building
        for building in buildings
        if building["geometry"].covers(clicked_point)
    ]

    # --------------------------------------------------------
    # NO EXACT BUILDING MATCH
    # --------------------------------------------------------

    if not matches:

        nearby_candidates = find_nearby_buildings(
            latitude,
            longitude
        )

        return {

            "match_type": "none",

            "message": (
                "No exact building polygon found. "
                "Nearby mapped buildings are listed."
            ),

            "latitude": latitude,

            "longitude": longitude,

            "search_radius_m": NEARBY_SEARCH_RADIUS_M,

            "distance_method": (
                "Approximate local metric projection"
            ),

            "nearby_candidates": nearby_candidates,

            "nearby_count": len(nearby_candidates)
        }

    # --------------------------------------------------------
    # EXACT BUILDING MATCH
    # --------------------------------------------------------

    building = matches[0]

    properties = building["properties"]

    geometry = building["geometry"]

    building_id = properties.get("building_id")

    google_height = height_lookup.get(building_id)

    # --------------------------------------------------------
    # GOOGLE HEIGHT EVIDENCE
    # --------------------------------------------------------

    height_evidence = {

        "value": google_height,

        "unit": "metres",

        "source": (
            "Google Open Buildings 2.5D"
            if google_height is not None
            else None
        ),

        "dataset_year": (
            2023
            if google_height is not None
            else None
        ),

        "measurement_type": (
            "model_estimate"
            if google_height is not None
            else "unknown"
        ),

        "verification_status": (
            "not_field_verified"
            if google_height is not None
            else "unavailable"
        ),

        "sampling_method": (
            "representative_point"
            if google_height is not None
            else None
        ),

        "confidence": None
    }

    # --------------------------------------------------------
    # BUILDING PROFILE
    # --------------------------------------------------------

    return {

        "match_type": "exact",

        # Identification
        "building_id": building_id,

        "latitude": latitude,

        "longitude": longitude,

        # OpenStreetMap attributes
        "building_type": properties.get(
            "building_type"
        ),

        "building_levels": properties.get(
            "building_levels"
        ),

        "height": properties.get(
            "height"
        ),

        "construction_date": properties.get(
            "construction_date"
        ),

        # OSM provenance
        "source": properties.get(
            "source",
            "OpenStreetMap"
        ),

        "source_timestamp": properties.get(
            "source_timestamp"
        ),

        # Google height estimate
        "estimated_height_m": google_height,

        "height_estimate_source": (
            "Google Open Buildings 2.5D"
            if google_height is not None
            else None
        ),

        "height_estimate_year": (
            2023
            if google_height is not None
            else None
        ),

        "height_verification": (
            "Model-estimated; not field-verified"
            if google_height is not None
            else "Unavailable"
        ),

        "height_sampling_method": (
            "Representative point"
            if google_height is not None
            else None
        ),

        # Structured evidence
        "attribute_evidence": {

            "estimated_height": height_evidence

        },

        # Building geometry
        "geometry": mapping(geometry),

        # Nearby search not applicable to exact matches
        "nearby_candidates": []
    }


# ============================================================
# 7. LOCAL VALIDATION
# ============================================================

if __name__ == "__main__":

    print("\nAI NETRA — BUILDING INTELLIGENCE")
    print("=" * 55)

    print(f"OSM buildings loaded: {len(buildings)}")

    print(f"Google heights loaded: {len(height_lookup)}")

    if not buildings:

        print("No buildings available for testing.")

        raise SystemExit(1)

    # --------------------------------------------------------
    # TEST 1 — EXACT BUILDING MATCH
    # --------------------------------------------------------

    sample_building = buildings[0]

    sample_point = (
        sample_building["geometry"].representative_point()
    )

    exact_result = identify_building(
        latitude=sample_point.y,
        longitude=sample_point.x
    )

    print("\nTEST 1 — EXACT BUILDING MATCH")
    print("=" * 55)

    print(
        "Building ID:",
        exact_result.get("building_id")
    )

    print(
        "Match type:",
        exact_result.get("match_type")
    )

    print(
        "Google estimated height:",
        exact_result.get("estimated_height_m"),
        "metres"
    )

    # --------------------------------------------------------
    # TEST 2 — NEARBY BUILDING SEARCH
    # --------------------------------------------------------

    # Offset from a known building's representative point.
    # The location may fall inside another building polygon;
    # the observed result determines whether fallback runs.

    test_latitude = sample_point.y + 0.00015

    test_longitude = sample_point.x + 0.00015

    nearby_result = identify_building(
        latitude=test_latitude,
        longitude=test_longitude
    )

    print("\nTEST 2 — NEARBY BUILDING SEARCH")
    print("=" * 55)

    print(
        "Match type:",
        nearby_result.get("match_type")
    )

    if nearby_result.get("match_type") == "none":

        print(
            "Nearby candidates:",
            nearby_result.get("nearby_count")
        )

        for candidate in nearby_result.get(
            "nearby_candidates",
            []
        ):

            print(
                candidate["building_id"],
                "=>",
                candidate["distance_m"],
                "metres"
            )

    else:

        print(
            "Test coordinate falls inside a building:",
            nearby_result.get("building_id")
        )

    print("\nVALIDATION COMPLETED")